<!--

	PHP e database
	Esempio pratico: popolamento di database con dati causali

	Disponibile su devACADEMY.it

-->

<?php

try
{
	$hostname="localhost";
	$username="root";
	$password="";
	$db="gestione_corsi";

	$num_record=30;
	$nomi=['Enzo', 'Lucia','Valeria', 'Patrizio', 'Michele', 'Mario'];
	$cognomi=['Volpi', 'Lupi','Tigri', 'Leoni', 'Orsi', 'Cavalli'];


	$db=new PDO("mysql:host=$hostname;dbname=$db", $username,$password);

	$query_titoli="SELECT id FROM titolo_studio";
	$risultato_titoli=$db->query($query_titoli);

	$titoli= $risultato_titoli->fetchAll(PDO::FETCH_ASSOC);

	var_dump($titoli);

	$sql="INSERT INTO allievo (nome, cognome, titolostudio_id)
			VALUES (:nome, :cognome, :titolostudio_id)";

	$stmt = $db->prepare($sql);

	for($i=0; $i<$num_record; $i++)
	{
		$nome_casuale=$nomi[rand(0, count($nomi)-1)];
		$cognome_casuale=$cognomi[rand(0, count($cognomi)-1)];
		$titolo_casuale=$titoli[rand(0, count($titoli)-1)]['id'];

		$stmt->bindParam(':nome', $nome_casuale, PDO::PARAM_STR);
		$stmt->bindParam(':cognome', $cognome_casuale, PDO::PARAM_STR);
		$stmt->bindParam(':titolostudio_id', $titolo_casuale, PDO::PARAM_INT);

		echo "Inserisco $nome_casuale $cognome_casuale con titolo di id $titolo_casuale <br>";

		$stmt->execute();
	}


}

catch(PDOException $e)
{
	echo "Attenzione, errore ... ".$e->getMessage();
	die("Fine connessione...");
}

?>