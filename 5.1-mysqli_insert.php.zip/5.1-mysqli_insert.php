<!--

	PHP e database
	Inserimento dati

	Disponibile su devACADEMY.it

-->

<?php

$mysqli= @new mysqli('localhost', 'root', '', 'gestione_corsi');
if ($mysqli->connect_error)
{
	echo "$mysqli->connect_error (#$mysqli->connect_errno)<br>";
	die("Fine esecuzione");
}

$nome="Giorgio";
$cognome="Azzurri";
$titolo=3;

$stmt=$mysqli->prepare("INSERT INTO allievo (id, nome, cognome, titolostudio_id)
 VALUES (1, ?,?,?)");
$stmt->bind_param('ssi', $nome, $cognome, $titolo);
if ($stmt->execute())
	echo "Nuovo id creato: $stmt->insert_id";
else
	echo "$mysqli->error ($mysqli->errno)";

$stmt->close();

$mysqli->close();

?>