<!--

	PHP e database
	Transazioni con PDO

	Disponibile su devACADEMY.it

-->

<?php

try
{
	$hostname="localhost";
	$username="root";
	$password="";
	$db="gestione_corsi";

	$db=new PDO("mysql:host=$hostname;dbname=$db", $username,$password);
	$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}

catch(PDOException $e)
{
	echo "Attenzione, errore ... ".$e->getMessage();
	die("Fine connessione...");
}

try{
	$db->beginTransaction();
	$db->exec("DELETE FROM corso WHERE id=2");
	$db->exec("DELETE FROM rel_corso_alievo WHERE corso_id=2");
	$db->commit();
}

catch(PDOException $e)
{
	$db->rollBack();
	echo $e->getMessage();
}

?>