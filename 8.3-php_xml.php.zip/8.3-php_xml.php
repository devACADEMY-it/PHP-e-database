<!--

	PHP e database
	Parsing XML

	Disponibile su devACADEMY.it

-->

<?php

$dati = <<<'QUI'
<?xml version='1.0' encoding='UTF-8'?>
<catalogo>
<libro>
	<autore>Alessandro Manzoni</autore>
	<titolo>Promessi sposi</titolo>
</libro>
<libro>
	<autore>Alberto Moravia</autore>
	<titolo>La ciociara</titolo>
</libro>
<libro>
	<autore>Giuseppe Tomasi di Lampedusa</autore>
	<titolo>Il gattopardo</titolo>
</libro>
</catalogo>
QUI;

$catalogo = simplexml_load_string($dati);

//var_dump($catalogo);

//var_dump($catalogo->libro[2]);

foreach($catalogo->libro as $l)
	echo "$l->titolo <br>";

?>