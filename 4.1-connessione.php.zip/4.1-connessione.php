<!--

	PHP e database
	Connessione ad un database

	Disponibile su devACADEMY.it

-->

<?php

$mysqli= @new mysqli('localhost', 'root', 'rgjeriogej', 'gestione_corsi');
if ($mysqli->connect_error)
{
	echo "Errore numero: ".$mysqli->connect_errno;
	echo "<br>";
	echo "Errore: ".$mysqli->connect_error;
	echo "<br>";
	die("Fine esecuzione");

}

var_dump($mysqli);

$mysqli->close();

?>