<!--

	PHP e database
	Esempio pratico: scambio dati tra database e file in altri formati

	Disponibile su devACADEMY.it

-->

<?php

try
{
	$hostname="localhost";
	$username="root";
	$password="";
	$db="gestione_corsi";

	$db=new PDO("mysql:host=$hostname;dbname=$db", $username,$password);

	$res=$db->query("SELECT * FROM allievo");

	$json = json_encode($res->fetchAll(PDO::FETCH_ASSOC));

	echo $json;

	echo "<br><br>";

	$dati=json_decode($json);

	echo $dati[3]->cognome;


}

catch(PDOException $e)
{
	echo "Attenzione, errore ... ".$e->getMessage();
	die("Fine connessione...");
}

?>