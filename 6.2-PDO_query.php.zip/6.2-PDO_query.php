<!--

	PHP e database
	Eseguire query con PDO

	Disponibile su devACADEMY.it

-->

<?php

try
{
	$hostname="localhost";
	$username="root";
	$password="";
	$db="gestione_corsi";

	$db=new PDO("mysql:host=$hostname;dbname=$db", $username,$password);

	$stat=$db->query("SELECT * FROM allievo");

	while($record=$stat->fetch(PDO::FETCH_NUM))
	{
		var_dump($record);
	}


}

catch(PDOException $e)
{
	echo "Attenzione, errore ... ".$e->getMessage();
	die("Fine connessione...");
}

?>