<!--

	PHP e database
	Introduzione ai Prepared Statement

	Disponibile su devACADEMY.it

-->

<?php

$mysqli= @new mysqli('localhost', 'root', '', 'gestione_corsi');
if ($mysqli->connect_error)
{
	echo "$mysqli->connect_error (#$mysqli->connect_errno)<br>";
	die("Fine esecuzione");
}

$titolo=2;

$query=$mysqli->prepare("SELECT * FROM allievo WHERE titolostudio_id=?");
$query->bind_param('i', $titolo);
$query->execute();
$result=$query->get_result();

var_dump($result->fetch_all());

$result->close();

$mysqli->close();

?>