<!--

	PHP e database
	Inserimento dati con PDO

	Disponibile su devACADEMY.it

-->

<?php

try
{
	$hostname="localhost";
	$username="root";
	$password="";
	$db="gestione_corsi";

	$db=new PDO("mysql:host=$hostname;dbname=$db", $username,$password);
}

catch(PDOException $e)
{
	echo "Attenzione, errore ... ".$e->getMessage();
	die("Fine connessione...");
}

  /*echo $db->exec("INSERT INTO allievo (nome, cognome, titolostudio_id)
			VALUES ('Vittorio', 'Neri', 1)");*/

  $nome='Vittorio';
  $cognome='Bianchi';
  $titolostudio_id=2;

  $sql="INSERT INTO allievo (nome, cognome, titolostudio_id)
			VALUES (:nome, :cognome, :titolostudio_id)";

  $stmt=$db->prepare($sql);

  $stmt->bindParam(':nome', $nome, PDO::PARAM_STR);
  $stmt->bindParam(':cognome', $cognome, PDO::PARAM_STR);
  $stmt->bindParam(':titolostudio_id', $titolostudio_id, PDO::PARAM_INT);

  $stmt->execute();

?>