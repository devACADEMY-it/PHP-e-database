<!--

	PHP e database
	Update dei dati con PDO

	Disponibile su devACADEMY.it

-->

<?php

try
{
	$hostname="localhost";
	$username="root";
	$password="";
	$db="gestione_corsi";

	$db=new PDO("mysql:host=$hostname;dbname=$db", $username,$password);

	$nome="Valeriano";
	$id=8;

	$sql="UPDATE allievo SET nome=:nome WHERE id=:id";

	$stmt=$db->prepare($sql);
	$stmt->bindParam(':nome', $nome, PDO::PARAM_STR);
	$stmt->bindParam(':id', $id, PDO::PARAM_INT);

	$stmt->execute();

	$num_righe=$stmt->rowCount();
	if ($num_righe==0)
		echo "Nessun record modificato";
	else
		echo "Modificate $num_righe righe";




}

catch(PDOException $e)
{
	echo "Attenzione, errore ... ".$e->getMessage();
	die("Fine connessione...");
}

?>