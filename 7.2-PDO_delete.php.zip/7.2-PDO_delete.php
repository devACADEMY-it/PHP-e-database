<!--

	PHP e database
	Cancellazione di dati con PDO

	Disponibile su devACADEMY.it

-->

<?php

try
{
	$hostname="localhost";
	$username="root";
	$password="";
	$db="gestione_corsi";

	$db=new PDO("mysql:host=$hostname;dbname=$db", $username,$password);

	$id=2;

	$sql="DELETE FROM allievo WHERE titolostudio_id=:id";
	$stmt=$db->prepare($sql);

	$stmt->bindParam(':id', $id, PDO::PARAM_INT);

	$stmt->execute();

	$num_righe=$stmt->rowCount();
	if ($num_righe==0)
		echo "Nessuna riga cancellata";
	else
		echo "Cancellate $num_righe righe";

	/*$sql="DELETE FROM allievo WHERE titolostudio_id=1";
	$num_righe=$db->exec($sql);

	if ($num_righe==0)
		echo "Nessuna riga cancellata";
	else
		echo "Cancellate $num_righe righe";*/


}

catch(PDOException $e)
{
	echo "Attenzione, errore ... ".$e->getMessage();
	die("Fine connessione...");
}

?>