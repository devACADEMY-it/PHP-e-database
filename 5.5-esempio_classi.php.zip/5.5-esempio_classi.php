<!--

	PHP e database
	Esempio pratico: spostamento di dati tra tabelle

	Disponibile su devACADEMY.it

-->

<?php

$mysqli= @new mysqli('localhost', 'root', '', 'gestione_corsi');
if ($mysqli->connect_error)
{
	echo "$mysqli->connect_error (#$mysqli->connect_errno)<br>";
	die("Fine esecuzione");
}

$corsi=$mysqli->query("SELECT * FROM corso");
$query=$mysqli->prepare("SELECT a.id, a.nome, a.cognome
FROM allievo as a JOIN rel_corso_allievo as r
ON a.id=r.allievo_id
JOIN corso as c ON r.corso_id=c.id
WHERE c.id=?
ORDER BY a.id");
while($singolo_corso=$corsi->fetch_assoc())
{
	$query->bind_param('i', $singolo_corso['id']);
	$query->execute();
	$result=$query->get_result();

	$file=fopen($singolo_corso['nome'].'.txt', 'w');
	foreach ($result->fetch_all() as $r)
	{
		$s=implode(';', $r).PHP_EOL;
		fwrite($file, $s);
	}
	fclose($file);
}
$query->close();
$mysqli->close();

?>