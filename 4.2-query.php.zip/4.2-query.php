<!--

	PHP e database
	Eseguire query

	Disponibile su devACADEMY.it

-->

<?php

$mysqli= @new mysqli('localhost', 'root', '', 'gestione_corsi');
if ($mysqli->connect_error)
{
	echo "$mysqli->connect_error (#$mysqli->connect_errno)<br>";
	die("Fine esecuzione");
}

$result=$mysqli->query("SELECT * FROM titolo_studio ORDER BY id");

$array=$result->fetch_all();
var_dump($array);
/*while($row=$result->fetch_assoc())
{
	printf("#%s %s <br>", $row['id'], $row['nome']);
}*/

/*$riga=$result->fetch_row();
var_dump($riga);

echo "<br>";

$riga=$result->fetch_assoc();
var_dump($riga);*/

$result->close();
$mysqli->close();

?>