<!--

	PHP e database
	Iniziare con PDO

	Disponibile su devACADEMY.it

-->

<?php

try
{
	$hostname="localhost";
	$username="root";
	$password="roggregpok";
	$db="gestione_corsi";

	$db=new PDO("mysql:host=$hostname;dbname=$db", $username,$password);
	echo "OK, connessione riuscita...";

}
catch(PDOException $e)
{
	echo "Attenzione, errore ... ".$e->getMessage();
	die("Fine connessione...");
}
echo "Fine script...";

?>