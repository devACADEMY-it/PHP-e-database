<!--

	PHP e database
	Parsing JSON

	Disponibile su devACADEMY.it

-->

<?php

	$dati["nome"]="Silvio";
	$dati["cognome"]="Verdi";
	$dati["eta"]=25;
	$dati["automunito"]=true;

	$json = json_encode($dati);

	echo $json;

	echo "<br>";

	$originale=json_decode($json);

	var_dump($originale);

?>