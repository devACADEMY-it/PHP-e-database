<!--

	PHP e database
	Cancellazione di dati

	Disponibile su devACADEMY.it

-->

<?php

$mysqli= @new mysqli('localhost', 'root', '', 'gestione_corsi');
if ($mysqli->connect_error)
{
	echo "$mysqli->connect_error (#$mysqli->connect_errno)<br>";
	die("Fine esecuzione");
}

$id=15;

$stmt=$mysqli->prepare("DELETE FROM allievo WHERE id=?");
$stmt->bind_param('i', $id);
if ($stmt->execute())
	echo "modificate $stmt->affected_rows righe";
else
	echo "Errore !!    $mysqli->error ($mysqli->errno)";

$stmt->close();


$mysqli->close();

?>