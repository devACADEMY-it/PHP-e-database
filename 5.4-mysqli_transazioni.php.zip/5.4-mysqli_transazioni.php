<!--

	PHP e database
	Transazioni

	Disponibile su devACADEMY.it

-->

<?php

$mysqli= @new mysqli('localhost', 'root', '', 'gestione_corsi');
if ($mysqli->connect_error)
{
	echo "$mysqli->connect_error (#$mysqli->connect_errno)<br>";
	die("Fine esecuzione");
}

$allievi = array(
	array("id"=> 20,"nome"=>"Luigi", "cognome" => "Rossi", "titolostudio_id" => 2),
	array("id"=> 1, "nome"=>"Giovanni", "cognome" => "Neri", "titolostudio_id" => 1)
);

$stmt=$mysqli->prepare("INSERT INTO allievo (id, nome, cognome, titolostudio_id)
 VALUES (?,?,?,?)");

 $mysqli->begin_transaction();
 foreach ($allievi as $a)
 {
	 $stmt->bind_param('issi', $a['id'], $a['nome'], $a['cognome'], $a['titolostudio_id']);
	 if ($stmt->execute())
		 echo "Nuovo id creato: $stmt->insert_id <br>";
	 else
	 {
		 echo "Errore!! $mysqli->error <br>";
		 $mysqli->rollback();
		 $stmt->close();
		 $mysqli->close();
		 exit();
	 }
 }

 $stmt->close();
 $mysqli->commit();


$mysqli->close();

?>