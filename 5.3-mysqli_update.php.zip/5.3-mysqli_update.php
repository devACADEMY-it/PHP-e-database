<!--

	PHP e database
	Update dei dati

	Disponibile su devACADEMY.it

-->

<?php

$mysqli= @new mysqli('localhost', 'root', '', 'gestione_corsi');
if ($mysqli->connect_error)
{
	echo "$mysqli->connect_error (#$mysqli->connect_errno)<br>";
	die("Fine esecuzione");
}

$nuovotitolo=3;
$id=9;

$stmt=$mysqli->prepare("UPDATE allievo SET titolostudio_id=?
 WHERE id=?");
$stmt->bind_param('ii', $nuovotitolo , $id);
if ($stmt->execute())
	echo "modificate $stmt->affected_rows righe";
else
	echo "Error!!   $mysqli->error ($mysqli->errno)";
$stmt->close();
$mysqli->close();

?>